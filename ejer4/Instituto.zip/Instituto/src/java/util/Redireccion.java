/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package util;

/**
 *
 * @author tonatihu
 * Created on 23-Feb-2019
 */
public class Redireccion {
    public static final int REGISTRAR_CARRERA = 0;
    public static final int VER_CARRERAS = 1;
    public static final int REGISTRAR_ALUMNO = 2;
    public static final int VER_ALUMNOS = 3;
    public static final int VER_DATOS = 4;
    public static final int HOME = 5;
}
